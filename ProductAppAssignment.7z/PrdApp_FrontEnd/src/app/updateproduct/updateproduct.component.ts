import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})
export class UpdateproductComponent implements OnInit {

  title: string = "Modify Product";

  constructor(private productService: ProductService, private router: Router) {

   }

  productItem=this.productService.product;
  // ngOnInit(): void {
  // }

  product: ProductModel[];

  ngOnInit(): void {
    this.product=this.productService.product;
    // alert("Update="+this.productService.product.product_id);
    console.log(this.product);
    }

  UpdateProduct(){
    // console.log(this.productItem);
    this.productService.updtProduct(this.productItem);
    console.log("Called");
    alert("Success");
    this.router.navigate(['/']);
  }

}
