import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  product;
  constructor(private http: HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/products")
  }
  newProduct(item){
    return this.http.post("http://localhost:3000/insert",{"product":item})
    .subscribe(data=>{console.log(data)})
    location.reload();
  }
  // updtProduct(item){
  //   return this.http.post("http://localhost:3000/update",{"product":item})
  //   .subscribe(data=>{console.log(data)})
  // }
  updtProduct(item){
     return this.http.put("http://localhost:3000/update",{"product":item})
     .subscribe(data=>{console.log(data)})
     location.reload();
  }
  deleteProduct(item){
    // item._id='ObjectId("'+item._id+'")';
    console.log(item._id);

    return this.http.delete(`http://localhost:3000/delete/${item.productId}`)
    .subscribe(data=>{console.log(data)})
    location.reload();
  }
}
