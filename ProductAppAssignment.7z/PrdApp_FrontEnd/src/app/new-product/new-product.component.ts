import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { ProductModel } from '../products/product.model';


@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {

  title: string = "Add Product";
  constructor(private productService: ProductService, private router: Router) { }
  productItem = new ProductModel(null,null,null,null,null,null,null,null);
  ngOnInit(): void {
  }
  
  AddProduct(){
    // alert ("clicked");
    // console.log(this.productItem);
    this.productService.newProduct(this.productItem);
    console.log("Called");
    alert("Success");
    this.router.navigate(['/']);
  
  }
  // buttonClicked(){
  //   console.log(this.productItem);
  //   alert ("clicked");
  // }

}



