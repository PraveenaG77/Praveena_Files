import { Component, OnInit } from '@angular/core';
import { ProductModel} from './product.model';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';
import {UpdateproductComponent} from '../updateproduct/updateproduct.component';


@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {
  
  title:string='Products-List';
  products: ProductModel[];
  imageWidth: number=50;
  imageMargin: number=2;
  ShowImage : boolean = false;

  // constructor (private productService: ProductService) {} --Working
  constructor(private productService: ProductService, private router: Router) { 
     
  }
  toggleImage(){
    this.ShowImage=!this.ShowImage;
  }

  UpdateProduct(product){
    console.log(product);
    this.productService.product=product;
  }
  DeleteProduct(product){
    console.log(product);
    this.productService.deleteProduct(product);
    console.log("Called");
    alert("Item Deleted");
    location.reload();
    // --Reload in service (deleteProduct) is more effective
  }
  ngOnInit(): void {
    this.productService.getProducts().subscribe((data)=>{
    this.products=JSON.parse(JSON.stringify(data));

    })
  }

  }
