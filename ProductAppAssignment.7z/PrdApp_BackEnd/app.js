const express = require('express');
const ProductData = require('./src/model/Productdata');
const cors = require('cors');

var bodyparser = require('body-parser');
var app = new express();
app.use(cors());
app.use(bodyparser.json());
app.get('/products',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")

    ProductData.find()
    .then(function (products){
        res.send(products);

    });
});

app.post('/insert',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    var product={
        productId: req.body.product.productId,
        productName: req.body.product.productName,
        productCode: req.body.product.productCode,
        releaseDate: req.body.product.releaseDate,
        description: req.body.product.description,
        price: req.body.product.price,
        starRating: req.body.product.starRating,
        imageUrl: req.body.product.imageUrl
    }

    var product=new ProductData(product);
    product.save();
})

app.put('/update',function(req,res){
        res.header("Access-control-Allow-Origin","*")
        res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
        console.log(req.body);
        console.log(req.body.product.productId);
        // const id = req.params.id;
        ProductData.findOneAndUpdate({productId: req.body.product.productId},
            {
                 $set: {
                            productId: req.body.product.productId,
                            productName: req.body.product.productName,
                            productCode: req.body.product.productCode,
                            releaseDate: req.body.product.releaseDate,
                            description: req.body.product.description,
                            price: req.body.product.price,
                            starRating: req.body.product.starRating,
                            imageUrl: req.body.product.imageUrl
                        }
                    },
                    {
                    upsert: true
                    })
                    .then(
                    console.log(req.body)
                    // res.redirect('/')
                    )

})

// app.post('/update',function(req,res){
//     res.header("Access-control-Allow-Origin","*")
//     res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
//     console.log(req.body);
   
//     console.log(req.body.product.productId);
//     var product={
//         productId: req.body.product.productId,
//         productName: req.body.products.productName,
//         productCode: req.body.products.productCode,
//         releaseDate: req.body.products.releaseDate,
//         description: req.bodyno.products.description,
//         price: req.body.products.price,
//         starRating: req.body.products.starRating,
//         imageUrl: req.body.products.imageUrl
//     }
//     // ProductData.findOneAndUpdate({productId: product.productId},
//     ProductData.findOneAndUpdate({productId: req.body.product.productId},
//         {
            
//             $set: {
//                 productId: req.body.product.productId,
//                 productName: req.body.product.productName,
//                 productCode: req.body.product.productCode,
//                 releaseDate: req.body.product.releaseDate,
//                 description: req.body.product.description,
//                 price: req.body.product.price,
//                 starRating: req.body.product.starRating,
//                 imageUrl: req.body.product.imageUrl
//             }
//         },
//         {
//         upsert: true
//         })
//         // .then(
//         // console.log("Product= "+product.productId)
//         // // res.redirect('/')
//         // )
//         })

            app.delete('/delete/:id',function(req,res){
            res.header("Access-control-Allow-Origin","*")
            res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
                   const id = req.params.id;
                //    console.log("Entered 2"+id);
            ProductData.deleteOne({"productId": id},    
            function(err,obj){
                console.log(id+" Deleted");
                console.log(err);
                console.log(obj);
            }
                )
        
})


app.listen(3000,function(){
   console.log('listening to port 3000');
})