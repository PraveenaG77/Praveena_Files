import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';
import {UserModel} from '../signup/signup.model';
import { LowerCasePipe } from '@angular/common';


// import { AlertService, AuthenticationService } from '../_services';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  // UserRow1;

  // loginForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;



  constructor(private productService: ProductService, private router: Router) { }
  title="Login";
  UserRow1=new UserModel(null,null,null,null,null);
  UserRow=new UserModel(null,null,null,null,null);
  ngOnInit(): void {
  }

  UserLogon(UserRow){
    // alert("Clicked");
    if (!(this.UserRow.Username==null) && !(this.UserRow.Pwd1==null)) {
      // alert("Clicked");
      // alert(UserRow);

      // this.productService.checkLogin(UserRow).subscribe((data)=>{
        this.productService.checkLogin(UserRow).subscribe((data)=>{
        this.UserRow1=JSON.parse(JSON.stringify(data));
        if (this.UserRow1===null){
          alert("Invalid Username/Password");
          return;
        }


        console.log(this.UserRow1);

        console.log(this.UserRow1.Username);
        alert("Welcome "+this.UserRow1.Username);
        this.productService.isLoggedIn=true;
        // if ((this.UserRow1.Username==='admin')&& (this.UserRow1.Pwd1==='admin@1234')){
        // || (this.UserRow1.Username.toLowerCase()==='administrator')  
        if ((this.UserRow1.Username.toLowerCase()==='admin') ){
              console.log(this.UserRow1.Username);
        this.productService.isAdmin=true;
      }
      else{
        this.productService.isAdmin=false;
      }
      this.router.navigate(['/header']);
      }
      )
    }
    else{
      alert("Fields cannot be left blank");
    }

  }



}
