import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-pl',
  templateUrl: './pl.component.html',
  styleUrls: ['./pl.component.css']
})
export class PLComponent implements OnInit {
  title="Profit & Loss Statement";
  ExpArray :number[]=[] ;
  PLList;
  PLListTotal;
   i: number;
   iExpTotal;
   iRevTotal;
  //  ExpTotal: number=0;
   ExpenseTotal: number;
  constructor(private productService: ProductService, private router: Router) { }

  getSum(){
    let Array1=[this.PLListTotal[0].DrTotal,this.PLListTotal[0].CrTotal];
    console.log(Array1);
    let sum = Array1.reduce((a, b) => a + b, 0)
    return sum;
  }
  
  getExpTotal(){
     var ExpTotal=0;
    for(var i=0;i<this.PLList.length;i++){
      if (this.PLList[i].details[0].AccountType==='Expense'){
      ExpTotal=ExpTotal+this.PLList[i].JVDrAmt;
    }
    }
    // console.log(ExpTotal);
    this.iExpTotal=ExpTotal;
    return ExpTotal;
    // var sum = ExpArray.reduce((a, b) => a + b, 0)
  }

  getRevTotal(){
    var RevTotal=0;
    for(var i=0;i<this.PLList.length;i++){
      if (this.PLList[i].details[0].AccountType==='Revenue'){
        RevTotal=RevTotal+this.PLList[i].JVCrAmt;
    }
    }
console.log(RevTotal);
this.iRevTotal=RevTotal;
return RevTotal;
  }

  getPLTotal(){
    alert("Called");
    var PLTotal=0;
    this.iRevTotal=this.getExpTotal();
    console.log(this.iRevTotal);
    this.iExpTotal=this.getRevTotal();
    console.log(this.iExpTotal);
    console.log((this.iRevTotal>this.iExpTotal? this.iRevTotal-this.iExpTotal: this.iExpTotal-this.iRevTotal));
//     for(var i=0;i<this.PLList.length;i++){
//       if (this.PLList[i].details[0].AccountType==='Revenue'){
//         RevTotal=RevTotal+this.PLList[i].JVCrAmt;
//     }
//     }
// console.log(RevTotal);
return (this.iRevTotal>this.iExpTotal? this.iRevTotal-this.iExpTotal: this.iExpTotal-this.iRevTotal);
  }

  ngOnInit(): void {
    this.productService.getPL().subscribe((data)=>{
    this.PLList=JSON.parse(JSON.stringify(data));
    console.log(this.PLList);
    })

    this.productService.getTBTotal().subscribe((data)=>{
      this.PLListTotal=JSON.parse(JSON.stringify(data));
      console.log(this.PLListTotal);
      console.log(this.PLListTotal.DrTotal)
    })
   

    // this.ExpenseTotal=this.getPLTotal();
    // console.log(this.ExpenseTotal);
  }
  
}

