import { Component, OnInit } from '@angular/core';
import {JVTransModel} from '../trans/trans.model';
import {JVTransHModel} from '../trans/transh.model';
import {JVTransDModel} from '../trans/transd.model';
import { AccountModel } from '../accounts/accounts.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-shw-trns',
  templateUrl: './shw-trns.component.html',
  styleUrls: ['./shw-trns.component.css']
})
export class ShwTrnsComponent implements OnInit {
  title='Transactions';
 
  ACList: AccountModel[];
  JVList: JVTransModel[];


  constructor(private productService: ProductService, private router: Router) {
    // alert("ShowAccounts"+" "+this.isLoggedIn+" "+this.isAdmin); 
  }
  isAdmin=this.productService.isAdmin;
  isLoggedIn=this.productService.isLoggedIn;
  AccountItem = new AccountModel(null,null,null,null);
  // JVList = new JVTransModel(null,null,null,null,0,0);

  UpdateTrans(Trns){
    // alert("Clicked update");
    console.log(Trns);
    this.productService.Trans=Trns;
  }
  DeleteTrans(Trns){
    console.log(Trns);
    this.productService.deleteTrns(Trns);
    // console.log("Called");
    alert("Item Deleted");
    // location.reload();
    // --Reload in service (deleteProduct) is more effective
    // this.router.navigate(['/Transactions']);
    this.ngOnInit();
  }

  ngOnInit(): void {
    this.productService.getTransactions().subscribe((data)=>{
    this.JVList=JSON.parse(JSON.stringify(data));
    console.log(this.JVList);
    })
    // alert("ShowAccounts"+" "+this.isLoggedIn+" "+this.isAdmin);
  }

}
