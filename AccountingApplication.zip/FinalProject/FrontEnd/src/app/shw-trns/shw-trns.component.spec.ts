import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShwTrnsComponent } from './shw-trns.component';

describe('ShwTrnsComponent', () => {
  let component: ShwTrnsComponent;
  let fixture: ComponentFixture<ShwTrnsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShwTrnsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShwTrnsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
