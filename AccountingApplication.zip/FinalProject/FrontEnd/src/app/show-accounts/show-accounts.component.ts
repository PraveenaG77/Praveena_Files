import { Component, OnInit } from '@angular/core';
import { AccountModel } from '../accounts/accounts.model';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-show-accounts',
  templateUrl: './show-accounts.component.html',
  styleUrls: ['./show-accounts.component.css']
})
export class ShowAccountsComponent implements OnInit {
  title="Accounts";
  accounts: AccountModel[];
  constructor(private productService: ProductService, private router: Router) {
    // alert("ShowAccounts"+" "+this.isLoggedIn+" "+this.isAdmin+" "+this.productService.isAdmin); 
  }
   isAdmin=this.productService.isAdmin;
   isLoggedIn=this.productService.isLoggedIn;
 
  UpdateAccount(account){
    // console.log(account);
    this.productService.account=account;
  }
  DeleteAccount(account){
    console.log(account);
    this.productService.deleteAccount(account);
    // console.log("Called");
    alert("Item Deleted");
    // location.reload();
    // --Reload in service (deleteProduct) is more effective
    // this.router.navigate(['/accounts']);
    this.ngOnInit();
  }
  ngOnInit(): void {
    this.productService.getAccounts().subscribe((data)=>{
    this.accounts=JSON.parse(JSON.stringify(data));
    console.log(this.accounts);
    })
    // alert("ShowAccounts"+" "+this.isLoggedIn+" "+this.isAdmin+" "+this.productService.isAdmin);
  }
  
}
