import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AccountsComponent } from './accounts/accounts.component';
import { ShowAccountsComponent } from './show-accounts/show-accounts.component';
import { UpdtAccntsComponent } from './updt-accnts/updt-accnts.component';
import { TransComponent } from './trans/trans.component';
import { ShwTrnsComponent } from './shw-trns/shw-trns.component';
import { UpdtTransComponent } from './updt-trans/updt-trans.component';
import { TBComponent } from './tb/tb.component';
import { PLComponent } from './pl/pl.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import {HeaderComponent} from './header/header.component';



const routes: Routes = [
{path: '',component: LoginComponent},
{path: 'addAccounts',component: AccountsComponent},
{path: 'accounts',component: ShowAccountsComponent},
{path: 'UpdateAccounts',component: UpdtAccntsComponent},
{path: 'addTrans',component: TransComponent},
{path: 'Transactions',component: ShwTrnsComponent},
{path: 'updateTrans',component: UpdtTransComponent},
{path: 'TB',component: TBComponent},
{path: 'PL',component: PLComponent},
{path: 'signup',component: SignupComponent},
{path: 'header',component: HeaderComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
