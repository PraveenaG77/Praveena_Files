import { Component, OnInit } from '@angular/core';
import {UserModel} from '../signup/signup.model';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  constructor(private productService: ProductService, private router: Router) { }
  title="Sign Up"
  UserRow=new UserModel(null,null,null,null,null);
  UserRow1=new UserModel(null,null,null,null,null);
  ngOnInit(): void {
  }

  ValidateUserInputs(){
    var RetValue: boolean=true;
    //Username
    var value1=this.UserRow.Username;
    var value2=this.UserRow.Username;
    value2=value2.replace(/[^a-zA-z0-9]/g,"");
    console.log(value2)
    if (value1!=value2){
      alert("Special characters not allowed in Username column.");
      RetValue=false;
    }
    //EmailId
        var regexp=/^([A-Za-z0-9\.-]+)@([A-Za-z0-9\-]+).([a-z]{2,3})(.[a-z]{2,3})?$/;
        var value1=this.UserRow.EmailId;
        if (regexp.test(value1)==false)
        {
          alert("Not a valid Email Id.");
          RetValue=false;
        }
          //Phone no.
          var regexp=/[0-9]{3}[0-9]{3}[0-9]{4}/;
          var value1=this.UserRow.PhoneNo;
          if (regexp.test(value1)==false)
          {
            alert("Not a valid Phone No.");
            RetValue=false;
          }
          //Password
          var regexp=/^([A-Za-z0-9]){8,15}$/;
          var value1=this.UserRow.Pwd1;
          if (regexp.test(value1)==false)
          {
            alert("Min. 8-15 characters. Atleast One Uppercase,One lowercase and one number.");
            RetValue=false;
          }
          //Confirm Password
          var value1=this.UserRow.Pwd1;
          var value2=this.UserRow.Pwd2;
          console.log(value2)
          if (value1!=value2){
            alert("Passwords must match.");
            RetValue=false;
          }

    return RetValue;
  }

  

  UserSignup(){
    if (!(this.UserRow.Username==null) && !(this.UserRow.Pwd1==null) && !(this.UserRow.Pwd2==null) && !(this.UserRow.EmailId==null)&& !(this.UserRow.PhoneNo==null)){
     
       var Value=this.ValidateUserInputs();

       if (Value===false){
         return Value;
       }
              
              this.productService.checkUser(this.UserRow)  
              .subscribe((data)=>{
                this.UserRow1 =JSON.parse(JSON.stringify(data));
                console.log(this.UserRow.Username);
                console.log(this.UserRow1);
                if (this.UserRow1==null){
                  this.productService.AddUser(this.UserRow);
                  console.log(this.UserRow);
                  this.router.navigate(['/']);
                }
                else{
                  alert("Username already exists...");
                  return false;
                }
              });
    }
    else{
      alert("Fields cannot be left blank.");
    }

    
  }

}
