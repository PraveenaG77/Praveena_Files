export class UserModel{
    constructor (
        public Username: string,
        public Pwd1: string,
        public Pwd2: string,
        public EmailId: string,
        public PhoneNo: string
){}
    
}