import { Component, OnInit } from '@angular/core';
import {JVTransModel} from '../trans/trans.model';
import {JVTransHModel} from '../trans/transh.model';
import {JVTransDModel} from '../trans/transd.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-tb',
  templateUrl: './tb.component.html',
  styleUrls: ['./tb.component.css']
})
export class TBComponent implements OnInit {
  title='Trial Balance';
 
  // ACList: AccountModel[];
  // TBList: JVTransModel[];
   TBList;
   TBListTotal;

  constructor(private productService: ProductService, private router: Router) { }

  ngOnInit(): void {
    this.productService.getTB().subscribe((data)=>{
    this.TBList=JSON.parse(JSON.stringify(data));
    console.log(this.TBList);
    })

    this.productService.getTBTotal().subscribe((data)=>{
      this.TBListTotal=JSON.parse(JSON.stringify(data));
      console.log(this.TBListTotal);
      console.log(this.TBListTotal.DrTotal)
    })

  }

}
