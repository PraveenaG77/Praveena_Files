import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TBComponent } from './tb.component';

describe('TBComponent', () => {
  let component: TBComponent;
  let fixture: ComponentFixture<TBComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TBComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
