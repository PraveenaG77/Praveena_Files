import { Injectable } from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  account;
  Trans;
    isAdmin=false;
    isLoggedIn=false;
  constructor(private http: HttpClient) { }
  getProducts(){
    return this.http.get("http://localhost:3000/products")
  }
  getAccounts(){
    return this.http.get("http://localhost:3000/accounts")
  }
  getTotal(){
    return this.http.get("http://localhost:3000/Total")
    // .subscribe(data=>{console.log(data)})
  }
  newProduct(item){
    return this.http.post("http://localhost:3000/insert",{"product":item})
    .subscribe(data=>{console.log(data)})
    location.reload();
  }
  newAccount(item){
    return this.http.post("http://localhost:3000/addAccounts",{"account":item})
    .subscribe(data=>{console.log(data)})
    location.reload();
  }
  // updtProduct(item){
  //   .subscribe(data=>{console.log(data)})
  // }
  updtAccount(account){
     return this.http.put("http://localhost:3000/update",{"account":account})
     .subscribe(data=>{console.log(data)})
     location.reload();
  }
  deleteAccount(account){
    // item._id='ObjectId("'+item._id+'")';
    console.log(account._id);

    return this.http.delete(`http://localhost:3000/delete/${account._id}`)
    .subscribe(data=>{console.log(data)})
    location.reload();
  }

  AddTrns(TrnsRec){
    return this.http.post("http://localhost:3000/addTrans",{"JVTrans":TrnsRec})
    .subscribe(data=>{console.log(data)})
    location.reload();
  }

  getTransactions(){
    return this.http.get("http://localhost:3000/Transactions")
  }

  updtTrans(Trns){
    return this.http.put("http://localhost:3000/updateTrans",{"JVTrans":Trns})
    .subscribe(data=>{console.log(data)})
    location.reload();
 }

 deleteTrns(Trns){
   // item._id='ObjectId("'+item._id+'")';
   console.log(Trns._id);

   return this.http.delete(`http://localhost:3000/deleteTrans/${Trns._id}`)
   .subscribe(data=>{console.log(data)})
   location.reload();
 }

 //Trial Balance
 getTB(){
  return this.http.get("http://localhost:3000/TB")
}

getTBTotal(){
  return this.http.get("http://localhost:3000/TBTotal")
}

//Login & Signup
AddUser(User){
  alert("Success");
  return this.http.post("http://localhost:3000/signup",{"users":User})
  .subscribe(data=>{console.log(data)})
  location.reload();
}

checkLogin(User){
  // return this.http.get(`http://localhost:3000/login/${User}`)
  return this.http.put("http://localhost:3000/login",{"users":User})
  // .subscribe(data=>{console.log(data)})
}

}
