import { Component, OnInit } from '@angular/core';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  // isAdmin: boolean =false;
  constructor(public productService: ProductService, public router: Router) {       
    // alert("constructor"+" "+this.isLoggedIn+" "+this.isAdmin);
  }
  title:string='Accounting Application';
  // isAdmin: boolean;
  // isLoggedIn: boolean;

  isAdmin=this.productService.isAdmin;
  isLoggedIn=this.productService.isLoggedIn;
  // alert(isLoggedIn);
  // alert(isAdmin);

  ngOnInit(): void {
      // alert("Init"+" "+this.isLoggedIn+" "+this.isAdmin);
  // alert(this.isAdmin);
  if (this.isLoggedIn==true){
    if (this.isAdmin==true){
      // alert("Init"+" "+this.isLoggedIn+" "+this.isAdmin);
    this.router.navigate(['/accounts']);
    }
    else{
      // alert("Init"+" "+this.isLoggedIn+" "+this.isAdmin);
      this.router.navigate(['/TB']);
    }
  }
  // else{
  //   alert("Not logged in");
  // }


  }

}