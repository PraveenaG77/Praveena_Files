import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdtAccntsComponent } from './updt-accnts.component';

describe('UpdtAccntsComponent', () => {
  let component: UpdtAccntsComponent;
  let fixture: ComponentFixture<UpdtAccntsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdtAccntsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdtAccntsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
