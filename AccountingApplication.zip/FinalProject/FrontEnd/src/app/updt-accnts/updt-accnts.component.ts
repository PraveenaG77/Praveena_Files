import { Component, OnInit } from '@angular/core';
import { AccountModel } from '../accounts/accounts.model';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-updt-accnts',
  templateUrl: './updt-accnts.component.html',
  styleUrls: ['./updt-accnts.component.css']
})
export class UpdtAccntsComponent implements OnInit {
  title="Modify Accounts";
 
  constructor(private productService: ProductService, private router: Router) { }
  
  // accounts: AccountModel[];
  accounts
  AcTypeList=['Assets','Liability','Expense','Revenue'];
  
  UpdateAccount(){
    // console.log(this.productItem);
    if (!((this.accounts.AccountCode===null) || (this.accounts.AccountName===null) || (this.accounts.AccountType===null) || (this.accounts.AccountDesc===null))){
    this.productService.updtAccount(this.accounts);
    console.log("Called");
    alert("Success");
    this.router.navigate(['/accounts']);
    }
  }
  
  ngOnInit(): void {
    this.accounts=this.productService.account;
    console.log(this.accounts)
  }

}