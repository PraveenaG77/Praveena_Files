import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';
import { AccountModel } from '../accounts/accounts.model';

@Component({
  selector: 'app-accounts',
  templateUrl: './accounts.component.html',
  styleUrls: ['./accounts.component.css']
})
export class AccountsComponent implements OnInit {
  title: string = "Add Account";
  AcTypeList=['Assets','Liability','Expense','Revenue'];
  // AcType='Expense';
  constructor(private productService: ProductService, private router: Router) { }
  AccountItem = new AccountModel(null,null,null,null);
  AccountItem1 = new AccountModel(null,null,null,null);
  ngOnInit(): void {
  }
  
  AddAccount(){
    if (!((this.AccountItem.AccountCode===null) || (this.AccountItem.AccountName===null) || (this.AccountItem.AccountType===null) || (this.AccountItem.AccountDesc===null))){
      this.productService.checkAccount(this.AccountItem)  
      .subscribe((data)=>{
        this.AccountItem1 =JSON.parse(JSON.stringify(data));
        if (this.AccountItem1){
         alert("Account Code/Account Name already exists... ")
          return false;
      }
      else{
        this.productService.newAccount(this.AccountItem);
        console.log("Called");
        alert("Success");
        this.router.navigate(['/accounts']);
      }
});
}
else{
    alert("Fields cannot be null or blank");
}

// Working -- Previous code without validation.
    // if ((this.AccountItem.AccountCode==null) || (this.AccountItem.AccountName==null) || (this.AccountItem.AccountType==null) || (this.AccountItem.AccountDesc==null)){
    //   alert("Fields cannot be left blank");
    //   return false;
    // }
    // this.productService.newAccount(this.AccountItem);
    // console.log("Called");
    // alert("Success");
    // this.router.navigate(['/accounts']);
  
  }
}