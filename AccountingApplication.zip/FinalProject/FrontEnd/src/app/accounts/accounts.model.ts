export class AccountModel{
    constructor (
        public AccountCode: string,
        public AccountName: string,
        public AccountType: string,
        public AccountDesc: string
){}
    
}