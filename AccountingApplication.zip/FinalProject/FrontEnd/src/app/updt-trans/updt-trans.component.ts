import { Component, OnInit } from '@angular/core';
import { AccountModel } from '../accounts/accounts.model';
import {ProductService} from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-updt-trans',
  templateUrl: './updt-trans.component.html',
  styleUrls: ['./updt-trans.component.css']
})
export class UpdtTransComponent implements OnInit {
  
  title="Modify Transactions";
  // accounts: AccountModel[];
  Trans
  ACList: AccountModel[];
   Ac :string[]=[] ;
 
  constructor(private productService: ProductService, private router: Router) { 

  }


  // AcTypeList=['Assets','Liability','Expense','Revenue'];
 
  
  UpdateTrans(){
    // console.log(this.productItem);
    if (!((this.Trans.JVDate===null) || (this.Trans.JVNo===null) || (this.Trans.JVDesc===null) || (this.Trans.JVDrAcName===null) || (this.Trans.JVCrAcName===null) || (this.Trans.JVAmount===0))){
    this.productService.updtTrans(this.Trans);
    console.log("Called");
    alert("Success");
    this.router.navigate(['/Transactions']);
    }
    else{
      alert("Fields cannot be null or blank");
      }
  }
  
  ngOnInit(): void {
    var i: number;
    
    this.productService.getAccounts().subscribe((data)=>{
      this.ACList=JSON.parse(JSON.stringify(data));
      // alert("Update Constructor");
      console.log(this.ACList);
      for(i=0;i<this.ACList.length;i++){
       this.Ac[i]=JSON.parse(JSON.stringify(this.ACList[i].AccountName));
      }
      console.log(this.Ac);
      this.Trans=this.productService.Trans;
      // alert("ngOnInit");
      console.log(this.Trans)
  
})
// console.log(this.Ac);
   
    // this.Trans=this.productService.Trans;
    // console.log(this.Trans)
  }

}