import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdtTransComponent } from './updt-trans.component';

describe('UpdtTransComponent', () => {
  let component: UpdtTransComponent;
  let fixture: ComponentFixture<UpdtTransComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdtTransComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdtTransComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
