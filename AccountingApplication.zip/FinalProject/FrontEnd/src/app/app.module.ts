import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { AccountsComponent } from './accounts/accounts.component';
import { ShowAccountsComponent } from './show-accounts/show-accounts.component';
import { TransComponent } from './trans/trans.component';
import { ShwTrnsComponent } from './shw-trns/shw-trns.component';
import { UpdtAccntsComponent } from './updt-accnts/updt-accnts.component';
import { UpdtTransComponent } from './updt-trans/updt-trans.component';
import { TBComponent } from './tb/tb.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { PLComponent } from './pl/pl.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    AccountsComponent,
    ShowAccountsComponent,
    TransComponent,
    ShwTrnsComponent,
    UpdtAccntsComponent,
    UpdtTransComponent,
    TBComponent,
    LoginComponent,
    SignupComponent,
    PLComponent

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
