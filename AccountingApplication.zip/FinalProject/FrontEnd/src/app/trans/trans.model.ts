export class JVTransModel{
    constructor (
        public JVDate: Date,
        public JVNo: string,
        public JVDesc: string,
        // public JVAcCode: string,
        public JVAcName: string,
        public JVDrAmt: number,
        public JVCrAmt: number

){}
    
}