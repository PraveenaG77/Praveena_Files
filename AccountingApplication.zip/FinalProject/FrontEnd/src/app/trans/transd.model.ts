export class JVTransDModel{
    constructor (
        public JVDate: Date,
        public JVNo: string,
        public JVAcName: string,
        public JVDrAmt: number,
        public JVCrAmt: number
){} 
}