export class JVTransHModel{
    constructor (
        public JVDate: Date,
        public JVNo: string,
        public JVDesc: string,
        // public JVAcCode: string,
        public JVDrAcName: string,
        public JVCrAcName: string,
        public JVAmount: number
){} 
}