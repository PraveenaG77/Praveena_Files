import { Component, OnInit } from '@angular/core';
import {JVTransModel} from '../trans/trans.model';
import {JVTransHModel} from '../trans/transh.model';
import {JVTransDModel} from '../trans/transd.model';
import { AccountModel } from '../accounts/accounts.model';
import { ProductService } from '../product.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-trans',
  templateUrl: './trans.component.html',
  styleUrls: ['./trans.component.css']
})
export class TransComponent implements OnInit {
  title: string = 'Add Transaction';
  // JVList: JVTransModel[];
  ACList: AccountModel[];
  // List: JVTransHModel[];
  constructor(private productService: ProductService, private router: Router) {

   }
  // AccountItem = new AccountModel(null,null,null,null);
  JVList = new JVTransHModel(null,null,null,null,null,0);
  List = new JVTransHModel(null,null,null,null,null,0);
  JVList1 = new JVTransDModel(null,null,null,0,0);

  

  ngOnInit(): void {
    this.productService.getAccounts().subscribe((data)=>{
      this.ACList=JSON.parse(JSON.stringify(data));
      console.log(this.ACList);
    })
 }

    AddTrans(){
      if (!((this.JVList.JVDate===null) || (this.JVList.JVNo===null) || (this.JVList.JVDesc===null) || (this.JVList.JVDrAcName===null) || (this.JVList.JVCrAcName===null) || (this.JVList.JVAmount===0))){
              this.productService.checkJVNo(this.JVList)  
              .subscribe((data)=>{
                this.List =JSON.parse(JSON.stringify(data));
                console.log(this.JVList.JVNo);
                console.log(this.List);
                if (this.List===null){
                this.productService.AddTrns(this.JVList);
                console.log("Called");
                alert("Success");
                this.router.navigate(['/Transactions']);
              }
              else{
                alert("JVNo. already exists... ")
                return false;
              }
      });
    }
    else{
            alert("Fields cannot be null or blank");
    }
}
}

  


