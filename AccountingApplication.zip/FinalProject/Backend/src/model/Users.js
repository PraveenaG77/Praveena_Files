const mongoose = require('mongoose');
const { start } = require('repl');
mongoose.connect('mongodb://localhost:27017/AccountsAppData');
const Schema = mongoose.Schema;

var NewUsersSchema = new Schema({
    Username: String,
    Pwd1: String,
    Pwd2: String,
    EmailId: String,
    PhoneNo: String
});

var User = mongoose.model('user',NewUsersSchema);
module.exports = User;