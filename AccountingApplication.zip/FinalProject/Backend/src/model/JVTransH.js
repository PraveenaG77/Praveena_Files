const mongoose = require('mongoose');
const { start } = require('repl');
mongoose.connect('mongodb://localhost:27017/AccountsAppData');
const Schema = mongoose.Schema;

var NewJVTransHSchema = new Schema({
    JVDate: Date,
    JVNo: String,
    JVDesc: String,
    JVDrAcName: String,
    JVCrAcName: String,
    JVAmount: Number
});

var JVTransH = mongoose.model('JVTrans_H',NewJVTransHSchema);
module.exports = JVTransH;