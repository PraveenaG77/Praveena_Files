const mongoose = require('mongoose');
const { start } = require('repl');
mongoose.connect('mongodb://localhost:27017/AccountsAppData');
const Schema = mongoose.Schema;

var NewAccountsSchema = new Schema({
    AccountCode : String,
    AccountName : String,
    AccountType : String,
    AccountDesc : String
});

var Accounts = mongoose.model('account',NewAccountsSchema);
module.exports = Accounts;