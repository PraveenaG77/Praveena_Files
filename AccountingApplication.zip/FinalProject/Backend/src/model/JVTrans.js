const mongoose = require('mongoose');
const { start } = require('repl');
mongoose.connect('mongodb://localhost:27017/AccountsAppData');
const Schema = mongoose.Schema;

var NewAccountsSchema = new Schema({
    JVDate: Date,
    JVNo: String,
    JVDesc: String,
    // public JVAcCode: string,
    JVAcName: String,
    JVDrAmt: Number,
    JVCrAmt: Number
});

var JVTrans = mongoose.model('JVTrans',NewAccountsSchema);
module.exports = JVTrans;