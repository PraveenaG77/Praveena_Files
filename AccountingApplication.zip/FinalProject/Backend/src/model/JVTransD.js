const mongoose = require('mongoose');
const { start } = require('repl');
mongoose.connect('mongodb://localhost:27017/AccountsAppData');
const Schema = mongoose.Schema;

var NewJVTransDSchema = new Schema({
    JVDate: Date,
    JVNo: String,
    JVAcName: String,
    // JVDrAcName: String,
    // JVCrAcName: String,
    JVDrAmt: Number,
    JVCrAmt: Number
});

var JVTransD = mongoose.model('JVTrans_D',NewJVTransDSchema);
module.exports = JVTransD;