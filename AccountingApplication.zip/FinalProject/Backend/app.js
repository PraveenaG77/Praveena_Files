const express = require('express');
const AccountsData = require('./src/model/Accounts');
const JVTransData = require('./src/model/JVTrans');
const JVTransHData = require('./src/model/JVTransH');
const JVTransDData = require('./src/model/JVTransD');
const UserData = require('./src/model/Users');
const cors = require('cors');

var bodyparser = require('body-parser');
var app = new express();
app.use(cors());
app.use(bodyparser.json());

// AccountsAPP
app.put('/chkAccount',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    console.log(req.body);
    console.log(req.body.account.AccountCode);
    console.log(req.body.account.AccountName);
    AccountsData.findOne( {$or:[{"AccountCode": req.body.account.AccountCode},{"AccountName": req.body.account.AccountName}]} )
    .then(function (account){
        res.send(account);
        console.log(account);
    }    );

});

app.post('/addAccounts',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    var account={
        AccountCode: req.body.account.AccountCode,
        AccountName: req.body.account.AccountName,
        AccountType: req.body.account.AccountType,
        AccountDesc: req.body.account.AccountDesc
    }

    var account=new AccountsData(account);
    account.save();
})

app.get('/accounts',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")

    AccountsData.find()
    .then(function (accounts){
        res.send(accounts);

    });
});


app.put('/update',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    console.log(req.body.account._id);
    // const id = req.params.id;
    AccountsData.findOneAndUpdate({_id: req.body.account._id},
        {
             $set: {
                        AccountCode: req.body.account.AccountCode,
                        AccountName: req.body.account.AccountName,
                        AccountType: req.body.account.AccountType,
                        AccountDesc: req.body.account.AccountDesc
                    }
                },
                {
                upsert: true
                })
                .then(
                console.log(req.body)
                // res.redirect('/')
                )

})

app.delete('/delete/:id',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
           const id = req.params.id;
        //    console.log("Entered 2"+id);
    AccountsData.deleteOne({"_id": id},    
    function(err,obj){
        // console.log(id+" Deleted");
        // console.log(err);
        console.log(obj);
    }
        )
})

// JVTransactions table
app.post('/addTrans',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    var TrnsH={
        JVDate: req.body.JVTrans_H.JVDate,
        JVNo: req.body.JVTrans_H.JVNo,
        JVDesc: req.body.JVTrans_H.JVDesc,
        JVDrAcName: req.body.JVTrans_H.JVDrAcName,
        JVCrAcName: req.body.JVTrans_H.JVCrAcName,
        JVAmount: req.body.JVTrans_H.JVAmount
    }
    var TrnsH=new JVTransHData(TrnsH);
    TrnsH.save();

    var TrnsD1={
        JVDate: req.body.JVTrans_H.JVDate,
        JVNo: req.body.JVTrans_H.JVNo,
        JVAcName: req.body.JVTrans_H.JVDrAcName,
        // JVCrAcName: req.body.JVTransD.JVCrAcName,
        JVDrAmt: req.body.JVTrans_H.JVAmount,
        JVCrAmt: 0
    }
    var TrnsD1=new JVTransDData(TrnsD1);
    TrnsD1.save();

    var TrnsD2={
        JVDate: req.body.JVTrans_H.JVDate,
        JVNo: req.body.JVTrans_H.JVNo,
        JVAcName: req.body.JVTrans_H.JVCrAcName,
        // JVCrAcName: req.body.JVTransD.JVCrAcName,
        JVDrAmt: 0,
        JVCrAmt: req.body.JVTrans_H.JVAmount
    }
    var TrnsD2=new JVTransDData(TrnsD2);
    TrnsD2.save();
})

app.get('/Transactions',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")

    JVTransHData.find()
    .then(function (Trns){
        res.send(Trns);

    });
});

app.post('/chkJV',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    console.log(req.body.JVTrans_H.JVNo);
    JVTransHData.findOne({"JVNo": req.body.JVTrans_H.JVNo})
    .then(function (Trns){
        res.send(Trns);
        console.log(Trns);
    });
});

app.put('/updateTrans',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    console.log(req.body.JVTrans_H._id);
    // const id = req.params.id;
    JVTransHData.findOneAndUpdate({_id: req.body.JVTrans_H._id},
        {
             $set: {
                   
                        JVDate: req.body.JVTrans_H.JVDate,
                        // JVNo: req.body.JVTrans_H.JVNo,
                        JVDesc: req.body.JVTrans_H.JVDesc,
                        JVDrAcName: req.body.JVTrans_H.JVDrAcName,
                        JVCrAcName: req.body.JVTrans_H.JVCrAcName,
                        JVAmount: req.body.JVTrans_H.JVAmount
                    }
                },
                {
                upsert: true
                })
                .then(
                console.log(req.body)
                // res.redirect('/')
                )

                JVTransDData.findOneAndUpdate({JVNo: req.body.JVTrans_H.JVNo,"$where": "return this.JVDrAmt>0"},
                    {
                         $set: {
                               
                                    JVDate: req.body.JVTrans_H.JVDate,
                                    // JVNo: req.body.JVTrans_H.JVNo,
                                    JVAcName: req.body.JVTrans_H.JVDrAcName,
                                    JVDrAmt: req.body.JVTrans_H.JVAmount,
                                    JVCrAmt: 0
                                }
                            },
                            {
                            upsert: true
                            })
                            .then(
                            console.log(req.body)
                            // res.redirect('/')
                            )
                            JVTransDData.findOneAndUpdate({JVNo: req.body.JVTrans_H.JVNo,"$where": "return this.JVCrAmt>0"},
                            {
                                 $set: {
                                       
                                            JVDate: req.body.JVTrans_H.JVDate,
                                            // JVNo: req.body.JVTrans_H.JVNo,
                                            JVAcName: req.body.JVTrans_H.JVCrAcName,
                                            JVDrAmt: 0,
                                            JVCrAmt: req.body.JVTrans_H.JVAmount
                                        }
                                    },
                                    {
                                    upsert: true
                                    })
                                    .then(
                                    console.log(req.body)
                                    // res.redirect('/')
                                    )

})

app.delete('/deleteTrans/:JVNo',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    // const id = req.params.id;       
    const JVNo = req.params.JVNo;
           
           console.log(JVNo);
    JVTransHData.deleteOne({"JVNo": JVNo},    
    function(err,obj){
        console.log(JVNo+" Deleted");
        console.log(err);
        console.log(obj);
    })
        console.log("Hdr deleted");
    JVTransDData.deleteMany({"JVNo": JVNo},{"new": true},    
    function(err,obj){
        console.log(JVNo+" Deleted");
        // console.log(err);
        // console.log(obj);
    }
        )
})

app.get('/Total',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    ProductData.aggregate(
        [
            {$group: {_id : 0, totalAmount : {$sum : '$price'}}}
        ]
        ).then(function (products){
                res.send(products)});
});

app.get('/TB',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    
    JVTransDData.aggregate(
        [
            {$group: {_id : '$JVAcName' , JVDrAmt : {$sum : '$JVDrAmt'}, JVCrAmt : {$sum : '$JVCrAmt'}}}
        ]
        ).then(function (Trns){
                res.send(Trns)
                console.log(Trns);
            });
            
});

app.get('/TBTotal',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    JVTransDData.aggregate(
        [
            {$group: {_id : 'Total', DrTotal : {$sum : '$JVDrAmt'}, CrTotal : {$sum : '$JVCrAmt'}}}
        ]
        ).then(function (Trns){
                res.send(Trns)});
                
});

app.get('/PL',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    
    JVTransDData.aggregate(
        [
            {$group: {_id : {JVAcName: "$JVAcName",AccountType: "$AccountType"} , 
            JVDrAmt : {$sum : '$JVDrAmt'}, JVCrAmt : {$sum : '$JVCrAmt'}}},
            {$lookup: {from: "accounts", localField: "_id.JVAcName",foreignField: "AccountName", as: "details"}}
        ]
        ).then(function (Trns){
                res.send(Trns)
                console.log(Trns);
            });
            
});

// Users table
app.post('/signup',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS");
    console.log(req.body);
    var User={
        Username: req.body.users.Username,
        Pwd1: req.body.users.Pwd1,
        Pwd2: req.body.users.Pwd2,
        EmailId: req.body.users.EmailId,
        PhoneNo: req.body.users.PhoneNo
        
    }
    var User=new UserData(User);
    User.save();
})

app.put('/chkUser',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    console.log(req.body.users.Username);
    UserData.findOne({"Username": req.body.users.Username})
    .then(function (user){
        res.send(user);
        console.log(user);
    });
});

// app.get('/login/:users',function(req,res){
    app.put('/login',function(req,res){
    res.header("Access-control-Allow-Origin","*")
    res.header("Access-Control-Allow-Methods: GET,POST,PATCH,PUT,DELETE,OPTIONS")
    
    // UserData.find()
    // .then(function (User){
    //     res.send(User);

    // });
    // console.log(req.body.Users.Username);
    console.log(req.body.users.Username);
    console.log(req.body.users.Pwd1);
    // console.log(req.body.user.Username);
        UserData.findOne({"Username": req.body.users.Username,"Pwd1": req.body.users.Pwd1})
    .then(function (User){
        res.send(User);
        console.log(User);

    });

});

app.listen(3000,function(){
   console.log('listening to port 3000');
})